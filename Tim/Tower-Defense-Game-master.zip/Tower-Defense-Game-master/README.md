# Tower-Defense-Game
The code from my 12 hour live stream where I created a tower defense game with pygame. For anyone wondering, Yes I'm insane and wrote this in 12 hours on a YouTube livestream without taking any breaks :)

You can view the livestream here: https://www.youtube.com/watch?v=iLHAKXQBOoA

# Asset Information
Unfortunatly I cannot release the assets used in this project. So you will not be able to run the code. 
