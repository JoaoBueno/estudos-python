# ABOUT

Python System Monitor (Psymon) is a cross-platform, task and 
performance monitor with the power of python


#DEPENDENCIES

*python (>= 2.6) & (< 2.8) 
*python-psutil (>= 0.4.0)
*python-qt4 (>= 4.8.0)
*python-qwt5-qt4 (>= 5.2.0)
*python-dateutil (>= 1.4.1)


#AUTHORS

*Dimitris Diamantis aka ftso
Email: kotsifi@gmail.com
Site: http://www.ftso.gr


#CREDITS

Thanks for their support or work:
*The development teams of the projects:
PyQt4, Python, Psutil, Python(x,y)
*The IT professors:
A.Sidiropoulos and S.Harhalakis