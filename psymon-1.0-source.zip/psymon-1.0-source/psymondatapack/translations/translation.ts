<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="proc_details_plotter.py" line="187"/>
        <source>Usage [%]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="networkplotter.py" line="145"/>
        <source>Timeline 60sec [h:m:s]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="networkplotter.py" line="155"/>
        <source>Usage [KB]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="47"/>
        <source>Psymon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="91"/>
        <source>Table View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="94"/>
        <source>Tree View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="102"/>
        <source>End Process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="186"/>
        <source>Process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="431"/>
        <source>Pid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="432"/>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="433"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="434"/>
        <source>Niceness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="146"/>
        <source>Cpu [%]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="147"/>
        <source>Memory [%]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="435"/>
        <source>Virtual Mem [MB]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="436"/>
        <source>RSS Mem [MB]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="437"/>
        <source>Start time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="438"/>
        <source>Cpu time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="439"/>
        <source>Threads</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="442"/>
        <source>I/O read [bytes]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="443"/>
        <source>I/O write [bytes]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="446"/>
        <source>Parent [name,pid]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="447"/>
        <source>Working directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="448"/>
        <source>Command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="382"/>
        <source>Local</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="383"/>
        <source>Remote</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="222"/>
        <source>Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="223"/>
        <source>Bytes Sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="224"/>
        <source>Bytes Receive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="225"/>
        <source>Packets Sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="226"/>
        <source>Packets Receive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="258"/>
        <source>Quick Search... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="313"/>
        <source>&lt;b&gt;Global Connections&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="319"/>
        <source>&lt;b&gt;Interfaces&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="356"/>
        <source>Thread  Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="357"/>
        <source>User  Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="358"/>
        <source>System  Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="381"/>
        <source>Connection Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="407"/>
        <source>Opened File Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="408"/>
        <source>Opened File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="440"/>
        <source>Connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="441"/>
        <source>Opened files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="444"/>
        <source>I/O read [KB/s]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="445"/>
        <source>I/O write [KB/s]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="470"/>
        <source>Partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="471"/>
        <source>Mountpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="472"/>
        <source>Filesystem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="473"/>
        <source>Total [MB]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="474"/>
        <source>Used [MB]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="475"/>
        <source>Free [MB]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="476"/>
        <source>Used %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="495"/>
        <source>&lt;b&gt;Partitions&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="506"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="509"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="516"/>
        <source>Application Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="523"/>
        <source>Tabs Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="527"/>
        <source>&amp;Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="536"/>
        <source>Configure Psymon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="541"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="556"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="602"/>
        <source>Fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="613"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="624"/>
        <source>About Psymon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="634"/>
        <source>About Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="671"/>
        <source>&lt;b&gt;Cpu History&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="671"/>
        <source> (Cpus: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="689"/>
        <source>&lt;b&gt;Memory History&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="689"/>
        <source> (Mem: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="689"/>
        <source>Swap: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="708"/>
        <source>&lt;b&gt;Network History&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="724"/>
        <source>&lt;b&gt;Disk I/O History&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="738"/>
        <source>Process Table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="739"/>
        <source>Cpu &amp;&amp; Memory Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="740"/>
        <source>Disks Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="741"/>
        <source>Network Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main_window.py" line="742"/>
        <source>Process Detailed Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="proc_details_plotter.py" line="174"/>
        <source>Timeline </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="proc_details_plotter.py" line="174"/>
        <source>min [h:m:s]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon.py" line="142"/>
        <source>...stop existing!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon.py" line="286"/>
        <source>Permission denied!
You should run Psymon as administrator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon.py" line="356"/>
        <source>&lt;b&gt;Disks I/O History&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon.py" line="338"/>
        <source>&lt;b&gt;Disk&lt;b&gt; (</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon.py" line="388"/>
        <source>) &lt;/b&gt;I/O History&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon.py" line="405"/>
        <source>&lt;b&gt;Netwok History&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon.py" line="388"/>
        <source>&lt;b&gt;Interface&lt;b&gt; (</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon.py" line="499"/>
        <source>Application restart is required for the language changes to take effect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon.py" line="712"/>
        <source>Please select a process first.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon.py" line="731"/>
        <source>&lt;b&gt;Process: &lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon.py" line="1388"/>
        <source>AccessDenied</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon.py" line="769"/>
        <source>Zero or AccessDenied</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon.py" line="1026"/>
        <source>Procs:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon.py" line="1028"/>
        <source>Cpu:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon.py" line="1032"/>
        <source>Mem:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon.py" line="1034"/>
        <source>Swap:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon.py" line="1036"/>
        <source>Up:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon.py" line="1048"/>
        <source>Net:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon.py" line="1052"/>
        <source>Disk:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Psymon_About</name>
    <message>
        <location filename="psymon_about.py" line="37"/>
        <source>About Psymon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon_about.py" line="48"/>
        <source>&lt;h4&gt;About&lt;/h4&gt;Python System Monitor (&lt;i&gt;Psymon&lt;/i&gt;)&lt;br&gt;Cross-platform, task and performance monitor.&lt;br&gt;Version: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon_about.py" line="49"/>
        <source>(&lt;b&gt;C&lt;/b&gt;) 2011-2012 Dimitris Diamantis&lt;br&gt;&lt;br&gt;&lt;h4&gt;License&lt;/h4&gt;Psymon is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License 3 as published by the Free Software Foundation.&lt;br&gt;This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the GNU General Public License for more details.You should have received a copy of the GNU General Public License along with this program.  If not, see [http://www.gnu.org/licenses/].</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon_about.py" line="50"/>
        <source>&lt;br&gt;&lt;h4&gt;Contact&lt;/h4&gt;Dimitris Diamantis &lt;i&gt;aka&lt;/i&gt; ftso&lt;br&gt;email: kotsifi@gmail.com&lt;br&gt;website: www.ftso.gr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon_about.py" line="51"/>
        <source>&lt;br&gt;&lt;h4&gt;Credits&lt;/h4&gt;Thanks for their support or work:&lt;br&gt;-The development teams of the projects:&lt;br&gt;PyQt4, Python, Psutil, Python(x,y), Oxygen-icons&lt;br&gt;-The IT professors:&lt;br&gt;A.Sidiropoulos and S.Harhalakis</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Psymon_Help</name>
    <message>
        <location filename="psymon_help.py" line="33"/>
        <source>Psymon Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon_help.py" line="41"/>
        <source>&lt;h4&gt;Introduction&lt;/h4&gt;Python System Monitor (&lt;i&gt;Psymon&lt;/i&gt;)&lt;br&gt; is a cross-platform, task and performance monitor.&lt;br&gt;&lt;br&gt;Fearures:&lt;br&gt;*Global process monitoring&lt;br&gt;*System load history (cpu,memory,netwok and disks)&lt;br&gt;*Disks informations&lt;br&gt;*Network connections&lt;br&gt;*Detailed informations and cpu, memory percentage history per process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon_help.py" line="42"/>
        <source>&lt;h4&gt;Getting started&lt;/h4&gt;The Psymon main window consists of a menu bar, the work space and a status bar.&lt;br&gt;The worksheets of the Psymon are: &lt;b&gt;&lt;i&gt;Process Table, Cpu &amp; Memory Info, Disks Info, Network Info&lt;/b&gt;&lt;/i&gt; and &lt;b&gt;&lt;i&gt;Detailed Process Info&lt;/b&gt;&lt;/i&gt;. The &lt;i&gt;Process Table&lt;/i&gt; lists the running processes with many informations about them. The &lt;i&gt;Cpu &amp; Memory Info&lt;/i&gt; worksheet shows graphs of system utilization: Cpu history and Memory-Swap history. The &lt;i&gt;Disks Info&lt;/i&gt; worksheet shows a graph and a table of disks utilization and informations. The &lt;i&gt;Network Info&lt;/i&gt; worksheet shows a graph and a table of network interfaces utilization and informations.Also shows a table with the global network connections.The &lt;i&gt;Detailed Process Info&lt;/i&gt; worksheet shows a graph and three tables with informations of one selected process from the &lt;i&gt;Process Table&lt;/i&gt; worksheet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon_help.py" line="43"/>
        <source>&lt;h4&gt;Process Table&lt;/h4&gt;The Process Table gives you a list of processes on your system. The list can be sorted by each column. Just press the left mouse button at the head of the column. If you have selected one process you can press the End Process button to terminate it. If this applications still have unsaved data this data will be lost. So use this button with care. The &lt;i&gt;Quick Search...&lt;/i&gt; filter which processes are shown by the text given here. The text can be a partial string match of the Name, Pid or Username of the process. The compobox in the right of the &lt;i&gt;Quick Search...&lt;/i&gt; can used to change the process table in &lt;i&gt;Table View&lt;/i&gt; or &lt;i&gt;Tree View&lt;/i&gt;. Also if you perform a double left click on a process you moved to the &lt;i&gt;Detailed Process Info&lt;/i&gt; worksheet where you can see detailed informations about this process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon_help.py" line="44"/>
        <source>&lt;h4&gt;Graphs&lt;/h4&gt;The graphs of the Psymon on the axis Y shows percentage or KiloBytes (KB) and on the axis X the time. On the right side of every graph-box there are buttons that can be used to show or hide graphs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon_help.py" line="45"/>
        <source>&lt;br&gt;&lt;i&gt;Note:&lt;/i&gt; The multiples of a byte in Psymon are decimals and not binaries. For example, a KiloByte is 1000 bytes and not 1024 bytes, which is a KibiByte.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Psymon_Settings</name>
    <message>
        <location filename="psymon_settings.py" line="32"/>
        <source>Psymon Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon_settings.py" line="40"/>
        <source>Gui Style: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon_settings.py" line="49"/>
        <source>Application Language: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon_settings.py" line="59"/>
        <source>Tabs Orientation: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon_settings.py" line="74"/>
        <source>Worksheet 5 Graph Timeline: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon_settings.py" line="79"/>
        <source>minutes </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon_settings.py" line="94"/>
        <source>Process Table Refresh: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="psymon_settings.py" line="110"/>
        <source>Defaults</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
