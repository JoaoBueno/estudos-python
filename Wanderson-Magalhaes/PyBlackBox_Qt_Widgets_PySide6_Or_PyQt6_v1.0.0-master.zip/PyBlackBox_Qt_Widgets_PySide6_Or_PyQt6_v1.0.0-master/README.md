# PyBlackBox Qt Widgets - PySide6 Or PyQt6 v1.0.0
> This was just a study project designed to study some custom widgets that are being implemented in the new project called PyOneDark.

This project needs many adjustments, you can improve and use as you wish if you want to continue the project and create your personal messaging application.

# Learn more about this project by watching this video:
> https://youtu.be/jfDwGog6G4U

![PyBlackBOX](https://user-images.githubusercontent.com/60605512/119701462-bb95e980-be2a-11eb-8d97-79cd5a8271bd.png)

# WARNING
>To use this project with PyQt you need to rename some classes, such as Slot to pyqtSlot, Signal to pyqtSignal among others.
