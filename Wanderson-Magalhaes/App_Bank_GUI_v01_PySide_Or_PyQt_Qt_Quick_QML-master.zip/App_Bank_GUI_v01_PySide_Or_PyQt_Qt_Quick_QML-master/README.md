# App Bank GUI | PySide Or PyQt | Qt Quick And QML
> ## :gift: **//// DONATE ////**
> ## 🔗 Donate (Gumroad): https://gum.co/mHsRC

# YOUTUBE VIDEO
> https://youtu.be/0xvZndxIyfk

![app_bank](https://user-images.githubusercontent.com/60605512/115913997-b7e7ff00-a447-11eb-95ca-5aa1c3684edf.png)
