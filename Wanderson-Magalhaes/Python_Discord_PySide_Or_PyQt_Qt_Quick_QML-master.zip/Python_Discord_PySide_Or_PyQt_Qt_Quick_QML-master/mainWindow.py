# This Python file uses the following encoding: utf-8


class MainWindow:
    def __init__(self):
        pass
