# Python Discord | PySide Or PyQt | Qt Quick And QML
> ## :gift: **//// DONATE ////**
> ## 🔗 Donate (Gumroad): https://gum.co/mHsRC

# YOUTUBE VIDEO
> https://youtu.be/ylaqZRBjAEw

![discord](https://user-images.githubusercontent.com/60605512/115913460-03e67400-a447-11eb-8a37-7d78ec016a89.png)
